"""
Schema definitions for Vyom
""" 