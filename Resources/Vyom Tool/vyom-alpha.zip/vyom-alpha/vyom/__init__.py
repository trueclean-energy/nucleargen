"""
Vyom: Nuclear LMP Safety Case Acceleration using PRA
"""

__version__ = '0.1.0' 